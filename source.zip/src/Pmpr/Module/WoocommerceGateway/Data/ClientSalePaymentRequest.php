<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66222fe08605d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceGateway\Data; class ClientSalePaymentRequest { public $Amount; public $OrderId; public $CallBackUrl; public $LoginAccount; public $AdditionalData; public function qiccuiwooiquycsg(array $yiosiwewiecqmkaa) { foreach ($yiosiwewiecqmkaa as $csgiecsagosuucqo => $eqgoocgaqwqcimie) { if (!isset($this->{$csgiecsagosuucqo})) { goto kqqiegkuqagcqsya; } $this->{$csgiecsagosuucqo} = $eqgoocgaqwqcimie; kqqiegkuqagcqsya: miweggwqeiaeweia: } kkumywowcoycymeo: } }
