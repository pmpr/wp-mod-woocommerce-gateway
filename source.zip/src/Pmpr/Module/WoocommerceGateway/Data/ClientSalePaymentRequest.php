<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8e10fe4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceGateway\Data; class ClientSalePaymentRequest { public $Amount; public $OrderId; public $CallBackUrl; public $LoginAccount; public $AdditionalData; public function qiccuiwooiquycsg(array $yiosiwewiecqmkaa) { foreach ($yiosiwewiecqmkaa as $csgiecsagosuucqo => $eqgoocgaqwqcimie) { if (!isset($this->{$csgiecsagosuucqo})) { goto foeeqckqsyockkak; } $this->{$csgiecsagosuucqo} = $eqgoocgaqwqcimie; foeeqckqsyockkak: oqugqwcyomiaaoqu: } eeqesooyqagwawae: } }
