<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6624d4dce2f97             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceGateway\Data; class ClientSalePaymentRequest { public $Amount; public $OrderId; public $CallBackUrl; public $LoginAccount; public $AdditionalData; public function qiccuiwooiquycsg(array $yiosiwewiecqmkaa) { foreach ($yiosiwewiecqmkaa as $csgiecsagosuucqo => $eqgoocgaqwqcimie) { if (!isset($this->{$csgiecsagosuucqo})) { goto cuumeogeomowqisc; } $this->{$csgiecsagosuucqo} = $eqgoocgaqwqcimie; cuumeogeomowqisc: uiosisocuwokwkie: } iikiiioqiyegyaak: } }
