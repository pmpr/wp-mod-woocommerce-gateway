<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620f0efea924             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceGateway; use nusoap_client; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Saderat extends Gateway { protected function ussowkigumoaoowo($umwqusowiqmyseom) { } protected function aqmwamyiwgeeymqa($umwqusowiqmyseom) { } protected function qyeykswoowmwqmai() { } }
